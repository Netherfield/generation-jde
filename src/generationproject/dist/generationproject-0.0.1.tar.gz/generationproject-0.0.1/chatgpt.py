
def make_essay():
    print("I have used ChatGPT for this essay, please enjoy!")