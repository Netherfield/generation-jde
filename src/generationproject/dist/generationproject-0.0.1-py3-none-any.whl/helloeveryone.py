
def greet_class():
    print("Hello everyone!")