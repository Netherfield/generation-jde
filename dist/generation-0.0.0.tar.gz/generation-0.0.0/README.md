## libgeneration library
Repository for generation's class libraries. Uploaded to TestPyPi.

# TO-DO
- ✅ Make it a python library
- ⬜ Upload to testpypi
- ⬜ Understand usage of setuptools-scm

